from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
# ... otras importaciones ...

login_manager = LoginManager()
